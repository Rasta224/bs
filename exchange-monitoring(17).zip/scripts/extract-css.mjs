import { readFileSync, writeFileSync } from 'fs';

const html = readFileSync('public/bestchange.html', 'utf-8');

// Extract all <style> blocks
const styleRegex = /<style[^>]*>([\s\S]*?)<\/style>/gi;
let allCSS = '';
let match;
while ((match = styleRegex.exec(html)) !== null) {
  allCSS += match[1] + '\n\n';
}

writeFileSync('app/bestchange.css', allCSS, 'utf-8');
console.log(`Extracted CSS to app/bestchange.css (${allCSS.length} characters)`);
