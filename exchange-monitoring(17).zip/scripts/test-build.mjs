import { execSync } from 'child_process';

try {
  console.log("[v0] Testing next build...");
  const result = execSync('cd /vercel/share/v0-project && npx next build 2>&1', {
    timeout: 60000,
    encoding: 'utf-8'
  });
  console.log("[v0] Build output:", result.slice(-3000));
} catch (err) {
  console.log("[v0] Build FAILED:", err.stdout?.slice(-3000) || "no stdout");
  console.log("[v0] stderr:", err.stderr?.slice(-3000) || "no stderr");
}
