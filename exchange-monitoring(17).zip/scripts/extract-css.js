import { readFileSync, writeFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..');
console.log('Root:', root);
console.log('CWD:', process.cwd());

const html = readFileSync(resolve(root, 'public/bestchange.html'), 'utf8');
const styleStart = html.indexOf('<style>');
const styleEnd = html.indexOf('</style>');

if (styleStart !== -1 && styleEnd !== -1) {
  const css = html.substring(styleStart + 7, styleEnd);
  writeFileSync(resolve(root, 'app/bestchange.css'), css.trim());
  console.log('CSS extracted successfully, length:', css.trim().length);
} else {
  console.log('Could not find style tags');
}
