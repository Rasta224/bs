import os, subprocess

# Find file location
result = subprocess.run(['find', '/', '-name', 'bestchange.html', '-maxdepth', '8'], 
                       capture_output=True, text=True, timeout=10)
print("Find results:", result.stdout.strip())
print("CWD:", os.getcwd())
print("Listing CWD:", os.listdir('.'))

# Also try relative
for p in ['.', '..', '../public', 'public']:
    if os.path.isdir(p):
        print(f"Contents of {p}:", os.listdir(p))
