import { NextResponse } from "next/server"
import { buildExchangePage, parseExchangeSlug, buildMainPage } from "@/lib/html-processor"

export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params

  // Only handle exchange direction slugs (xxx-to-yyy)
  if (!slug.includes("-to-")) {
    // For non-exchange slugs, redirect to main
    return NextResponse.redirect(new URL("/", request.url))
  }

  const { fromId, toId, fromSlug, toSlug } = parseExchangeSlug(slug)
  if (!fromId || !toId) {
    // Unknown currencies, show main page
    const html = buildMainPage()
    return new NextResponse(html, {
      headers: { "Content-Type": "text/html; charset=utf-8" },
    })
  }

  const html = buildExchangePage(fromId, toId, fromSlug ?? undefined, toSlug ?? undefined)
  if (!html) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=60",
    },
  })
}
