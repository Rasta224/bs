import type { Metadata, Viewport } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "Мониторинг обменников, лучшие курсы от надежных обменных пунктов",
  description:
    "BestChange - мониторинг обменников, который автоматически находит самые выгодные курсы обмена валют.",
}

export const viewport: Viewport = {
  width: 1020,
  userScalable: true,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  )
}
