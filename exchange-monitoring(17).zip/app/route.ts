import { NextResponse } from "next/server"
import { buildMainPage } from "@/lib/html-processor"

export async function GET() {
  const html = buildMainPage()
  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=60",
    },
  })
}
