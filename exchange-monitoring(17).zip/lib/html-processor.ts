import { readFileSync } from "fs"
import { join } from "path"
import { currencies, exchangers, generateRates, formatNumber } from "@/lib/exchange-data"

let cachedHtml: string | null = null

function getBaseHtml(): string {
  if (!cachedHtml) {
    const htmlPath = join(process.cwd(), "public", "bestchange.html")
    cachedHtml = readFileSync(htmlPath, "utf-8")
  }
  return cachedHtml
}

// Slug-to-currency-id mapping (covers all major directions)
const SLUG_MAP: Record<string, string> = {
  // Crypto
  "bitcoin": "btc", "bitcoin-ln": "btc", "bitcoin-bep20": "btc",
  "bitcoin-cash": "bch", "bitcoin-sv": "bch",
  "ethereum": "eth", "ethereum-bep20": "eth", "ethereum-arbitrum": "eth", "ethereum-optimism": "eth",
  "ethereum-classic": "eth", "wrapped-eth": "eth", "wrapped-bitcoin": "btc",
  "litecoin": "ltc", "ripple": "xrp", "monero": "xmr",
  "dogecoin": "doge", "tron": "trx", "solana": "sol",
  "binance-coin": "bnb-bep20", "binance-coin-bep2": "bnb-bep20",
  "ton": "ton", "toncoin": "ton", "cardano": "ada", "zcash": "zec",
  "polkadot": "sol", "chainlink": "eth", "polygon": "eth",
  "dash": "ltc", "stellar": "xrp", "cosmos": "sol",
  "shiba-inu": "doge", "shiba-inu-bep20": "doge",
  "pepe": "doge", "notcoin": "ton", "trump": "sol",
  "near": "sol", "avalanche": "sol", "aptos": "sol",
  "arbitrum": "eth", "optimism": "eth", "sui": "sol", "kaspa": "btc",
  // Stablecoins
  "tether-erc20": "usdt-erc20", "tether-trc20": "usdt-trc20",
  "tether-bep20": "usdt-bep20", "tether-sol": "usdt-trc20",
  "tether-polygon": "usdt-trc20", "tether-ton": "usdt-ton",
  "tether-optimism": "usdt-erc20", "tether-arbitrum": "usdt-erc20",
  "tether-avax": "usdt-erc20", "tether": "usdt-erc20", "usdt-near": "usdt-erc20",
  "usd-coin": "usdc-erc20", "usd-coin-trc20": "usdc-erc20",
  "usd-coin-bep20": "usdc-erc20", "usd-coin-sol": "usdc-erc20",
  "usd-coin-polygon": "usdc-erc20", "usdc-arbitrum": "usdc-erc20",
  "usdc-optimism": "usdc-erc20", "usdc-near": "usdc-erc20",
  "trueusd": "usdt-erc20", "trueusd-trc20": "usdt-trc20",
  "pax-dollar": "usdc-erc20", "dai": "usdc-erc20", "busd": "usdt-bep20",
  "xaut-erc20": "btc",
  // E-money
  "wmz": "wmz", "wme": "wmz",
  "yoomoney": "iomoney", "iomoney": "iomoney",
  "paypal-usd": "paypal", "paypal-euro": "paypal", "paypal-gbp": "paypal",
  "paypal-cad": "paypal", "paypal-aud": "paypal",
  "volet-usd": "volet", "volet-euro": "volet", "volet-rub": "volet",
  "payeer": "payeer", "payeer-rub": "payeer", "payeer-euro": "payeer",
  "advanced-cash": "payeer", "advanced-cash-rub": "payeer",
  "advanced-cash-euro": "payeer", "advanced-cash-uah": "payeer",
  "skrill": "paypal", "skrill-euro": "paypal",
  "neteller": "paypal", "neteller-euro": "paypal",
  "paysera": "paypal", "paysera-euro": "paypal",
  "alipay": "alipay", "wechat": "alipay",
  "piastrix": "payeer", "piastrix-rub": "payeer",
  "capitalist": "payeer", "capitalist-euro": "payeer", "capitalist-rub": "payeer",
  // Cards
  "visa-mastercard-usd": "card-usd", "visa-mastercard-rub": "card-rub",
  "visa-mastercard-euro": "card-eur", "visa-mastercard-uah": "card-uah",
  "visa-mastercard-byn": "card-byn", "visa-mastercard-kzt": "card-kzt",
  "visa-mastercard-gbp": "card-usd", "visa-mastercard-cad": "card-usd",
  "visa-mastercard-try": "card-usd", "visa-mastercard-gel": "card-usd",
  "visa-mastercard-amd": "card-usd", "visa-mastercard-azn": "card-usd",
  "visa-mastercard-uzs": "card-usd", "visa-mastercard-kgs": "card-usd",
  "visa-mastercard-tjs": "card-usd", "visa-mastercard-mdl": "card-usd",
  "unionpay": "card-usd", "mir": "card-rub",
  // Banks
  "sberbank": "sber", "sbp": "sber",
  "alfaclick": "alfa", "alfa-bank": "alfa",
  "tinkoff": "tbank", "t-bank": "tbank",
  "vtb": "vtb", "raiffeisenbank": "vtb",
  "gazprombank": "vtb", "rosbank": "vtb", "otkritie": "vtb",
  "sovcombank": "vtb", "mts-bank": "vtb", "pochta-bank": "vtb",
  "privat24-uah": "privat24", "monobank-uah": "privat24",
  "kaspi-bank-kzt": "kaspi", "halyk-bank-kzt": "kaspi",
  "jysan-bank-kzt": "kaspi", "forte-bank-kzt": "kaspi",
  "belarusbank-byn": "card-byn", "prior-bank-byn": "card-byn",
  // Transfers
  "wu": "wu-usd", "contact": "wu-usd", "ria": "wu-usd",
  "gc-rub": "zk-rub", "zolotaya-korona": "zk-rub",
  // Cash
  "cash-ruble": "cash-rub", "dollar-cash": "cash-usd",
  "euro-cash": "cash-usd", "cash-uah": "cash-rub",
  "cash-btc": "btc",
}

export function parseExchangeSlug(slug: string): { fromSlug: string | null; toSlug: string | null; fromId: string | null; toId: string | null } {
  const match = slug.match(/^(.+)-to-(.+)$/)
  if (!match) return { fromSlug: null, toSlug: null, fromId: null, toId: null }
  return {
    fromSlug: match[1],
    toSlug: match[2],
    fromId: SLUG_MAP[match[1]] || null,
    toId: SLUG_MAP[match[2]] || null,
  }
}

const INTERACTIVE_SCRIPT = `
<script>
(function() {
  // Override goto_list to use local URLs instead of bestchange.ru
  if (typeof goto_list !== 'undefined') {
    // Save original reference
    var _orig_goto_list = goto_list;
  }
  // Replace goto_list globally
  window.goto_list = function(from, to) {
    var fromcur = from ? from : lc_curr;
    var tocur = to ? to : rc_curr;
    if (fromcur == 0 || tocur == 0) return;
    var fromSlug = cu_list[id2pos(fromcur)];
    var toSlug = cu_list[id2pos(tocur)];
    if (fromSlug && toSlug) {
      window.location.href = '/' + fromSlug + '-to-' + toSlug;
    }
  };

  // Override openDocument to navigate locally
  window.openDocument = function(url, newWin) {
    // Strip .html extension and rewrite bestchange.ru URLs to local
    url = url.replace(/\\.html$/, '');
    url = url.replace(/^https?:\\/\\/www\\.bestchange\\.ru/, '');
    if (!url.startsWith('/')) url = '/' + url;
    window.location.href = url;
  };

  // Clock
  function tick() {
    var dd = document.querySelector('#headinfo .localdate');
    if (dd) dd.textContent = new Date().toLocaleTimeString('ru-RU');
  }
  tick(); setInterval(tick, 1000);
})();
</script>`

function slugToDisplayName(slug: string): string {
  return slug.split("-").map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(" ")
}

function rewriteLinks(html: string): string {
  // Exchange direction links -> local routes (strip .html)
  html = html.replace(/https:\/\/www\.bestchange\.ru\/([\w-]+-to-[\w-]+)\.html/g, "/$1")
  // Other bestchange.ru page links -> local
  html = html.replace(/https:\/\/www\.bestchange\.ru\/([\w-]+)\.html/g, "/$1")
  // Remaining bestchange.ru links -> #
  html = html.replace(/https:\/\/www\.bestchange\.ru\/[^"']*/g, "#")
  return html
}

function buildRatesTable(fromId: string, toId: string): string {
  const from = currencies.find(c => c.id === fromId)!
  const to = currencies.find(c => c.id === toId)!
  const rates = generateRates(fromId, toId)

  return rates.map((rate, i) => {
    const ex = exchangers.find(e => e.id === rate.exchangerId)
    if (!ex) return ""
    return `<tr${i % 2 === 1 ? ' class="alt"' : ""}>
<td class="ir"><span class="io" id="io${i}"></span></td>
<td class="bj"><div class="pa"><a href="#">&nbsp;</a><div class="pc"><div class="ca" translate="no">${ex.name}</div></div></div></td>
<td class="bi"><div class="fs">${formatNumber(rate.give)} <small translate="no">${from.ticker}</small></div><div class="fm"></div></td>
<td class="bi">${formatNumber(rate.receive)} <small translate="no">${to.ticker}</small></td>
<td class="ar arp">${formatNumber(rate.reserve)}</td>
<td class="rw"><a href="#" class="rwan">${ex.reviews}</a><span class="end"></span></td>
</tr>`
  }).join("\n")
}

/** Main page - original HTML with links rewritten and interactivity injected */
export function buildMainPage(): string {
  let html = getBaseHtml()
  html = rewriteLinks(html)
  html = html.replace("</body>", INTERACTIVE_SCRIPT + "</body>")
  return html
}

/** Exchange direction page - original HTML with rates table replaced */
export function buildExchangePage(fromId: string, toId: string, fromSlug?: string, toSlug?: string): string | null {
  const from = currencies.find(c => c.id === fromId)
  const to = currencies.find(c => c.id === toId)
  if (!from || !to) return null

  // Use slug names for display if available
  const fromDisplayName = fromSlug ? slugToDisplayName(fromSlug) : from.name
  const toDisplayName = toSlug ? slugToDisplayName(toSlug) : to.name

  let html = getBaseHtml()
  html = rewriteLinks(html)

  const rates = generateRates(fromId, toId)
  const tableRows = buildRatesTable(fromId, toId)

  // Replace rates table content
  html = html.replace(
    /(<table id="content_table">[\s\S]*?<\/thead>\s*)<tbody>[\s\S]*?<\/tbody>/,
    `$1<tbody>\n${tableRows}\n</tbody>`
  )

  // Update title
  html = html.replace(
    /<title>.*?<\/title>/,
    `<title>Обмен ${fromDisplayName} на ${toDisplayName} - лучшие курсы | BestChange</title>`
  )

  // Update heading and intro
  html = html.replace(
    /<div id="small_text"[\s\S]*?<\/div>\s*(<div class="m-rate">)/,
    `<div id="small_text" class="intro">
<h1>Обмен ${fromDisplayName} на ${toDisplayName}</h1>
<p>Лучшие курсы обмена ${fromDisplayName} (${from.ticker}) на ${toDisplayName} (${to.ticker}) от ${rates.length} проверенных обменников. Выберите самый выгодный курс обмена.</p>
</div>
$1`
  )

  html = html.replace("</body>", INTERACTIVE_SCRIPT + "</body>")
  return html
}
