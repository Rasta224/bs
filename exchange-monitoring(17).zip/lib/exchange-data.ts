export interface Currency {
  id: string
  name: string
  shortName: string
  ticker: string
  group: string
}

export interface Exchanger {
  id: string
  name: string
  rating: number
  reviews: number
  age: string
  reserve: number
  minAmount: number
  maxAmount: number
}

export interface ExchangeRate {
  exchangerId: string
  give: number
  receive: number
  reserve: number
  minAmount: number
  maxAmount: number
}

export const currencies: Currency[] = [
  { id: "btc", name: "Bitcoin", shortName: "Bitcoin", ticker: "BTC", group: "Криптовалюты" },
  { id: "bch", name: "Bitcoin Cash", shortName: "Bitcoin Cash", ticker: "BCH", group: "Криптовалюты" },
  { id: "eth", name: "Ethereum", shortName: "Ethereum", ticker: "ETH", group: "Криптовалюты" },
  { id: "ltc", name: "Litecoin", shortName: "Litecoin", ticker: "LTC", group: "Криптовалюты" },
  { id: "xrp", name: "Ripple", shortName: "XRP", ticker: "XRP", group: "Криптовалюты" },
  { id: "xmr", name: "Monero", shortName: "Monero", ticker: "XMR", group: "Криптовалюты" },
  { id: "doge", name: "Dogecoin", shortName: "Dogecoin", ticker: "DOGE", group: "Криптовалюты" },
  { id: "trx", name: "TRON", shortName: "TRON", ticker: "TRX", group: "Криптовалюты" },
  { id: "bnb-bep20", name: "BNB BEP20", shortName: "BNB BEP20", ticker: "BNB", group: "Криптовалюты" },
  { id: "sol", name: "Solana", shortName: "Solana", ticker: "SOL", group: "Криптовалюты" },
  { id: "ton", name: "Toncoin", shortName: "Toncoin", ticker: "TON", group: "Криптовалюты" },
  { id: "ada", name: "Cardano", shortName: "Cardano", ticker: "ADA", group: "Криптовалюты" },
  { id: "zec", name: "Zcash", shortName: "Zcash", ticker: "ZEC", group: "Криптовалюты" },

  { id: "usdt-erc20", name: "Tether ERC20", shortName: "Tether ERC20", ticker: "USDT", group: "Стейблкоины" },
  { id: "usdt-trc20", name: "Tether TRC20", shortName: "Tether TRC20", ticker: "USDT", group: "Стейблкоины" },
  { id: "usdt-bep20", name: "Tether BEP20", shortName: "Tether BEP20", ticker: "USDT", group: "Стейблкоины" },
  { id: "usdt-ton", name: "Tether TON", shortName: "Tether TON", ticker: "USDT", group: "Стейблкоины" },
  { id: "usdc-erc20", name: "USDC ERC20", shortName: "USDC ERC20", ticker: "USDC", group: "Стейблкоины" },

  { id: "wmz", name: "WebMoney WMZ", shortName: "WebMoney", ticker: "WMZ", group: "Электронные деньги" },
  { id: "iomoney", name: "IOMoney RUB", shortName: "IOMoney", ticker: "RUB", group: "Электронные деньги" },
  { id: "paypal", name: "PayPal USD", shortName: "PayPal", ticker: "USD", group: "Электронные деньги" },
  { id: "volet", name: "Volet USD", shortName: "Volet", ticker: "USD", group: "Электронные деньги" },
  { id: "payeer", name: "Payeer USD", shortName: "Payeer", ticker: "USD", group: "Электронные деньги" },
  { id: "alipay", name: "Alipay CNY", shortName: "Alipay", ticker: "CNY", group: "Электронные деньги" },

  { id: "card-usd", name: "Банковская карта USD", shortName: "Банковская карта", ticker: "USD", group: "Банковские счета и карты" },
  { id: "card-rub", name: "Банковская карта RUB", shortName: "Банковская карта", ticker: "RUB", group: "Банковские счета и карты" },
  { id: "card-eur", name: "Банковская карта EUR", shortName: "Банковская карта", ticker: "EUR", group: "Банковские счета и карты" },
  { id: "card-uah", name: "Банковская карта UAH", shortName: "Банковская карта", ticker: "UAH", group: "Банковские счета и карты" },
  { id: "card-byn", name: "Банковская карта BYN", shortName: "Банковская карта", ticker: "BYN", group: "Банковские счета и карты" },
  { id: "card-kzt", name: "Банковская карта KZT", shortName: "Банковская карта", ticker: "KZT", group: "Банковские счета и карты" },

  { id: "sber", name: "Сбербанк RUB", shortName: "Сбербанк", ticker: "RUB", group: "Интернет-банкинг" },
  { id: "alfa", name: "Альфа-Банк RUB", shortName: "Альфа-Банк", ticker: "RUB", group: "Интернет-банкинг" },
  { id: "tbank", name: "Т-Банк RUB", shortName: "Т-Банк", ticker: "RUB", group: "Интернет-банкинг" },
  { id: "vtb", name: "ВТБ RUB", shortName: "ВТБ", ticker: "RUB", group: "Интернет-банкинг" },
  { id: "privat24", name: "Приват 24 UAH", shortName: "Приват 24", ticker: "UAH", group: "Интернет-банкинг" },
  { id: "kaspi", name: "Kaspi Bank KZT", shortName: "Kaspi Bank", ticker: "KZT", group: "Интернет-банкинг" },

  { id: "wu-usd", name: "WU USD", shortName: "WU", ticker: "USD", group: "Денежные переводы" },
  { id: "zk-rub", name: "ЗК RUB", shortName: "ЗК", ticker: "RUB", group: "Денежные переводы" },

  { id: "cash-rub", name: "Наличные RUB", shortName: "Наличные", ticker: "RUB", group: "Наличные деньги" },
  { id: "cash-usd", name: "Наличные USD", shortName: "Наличные", ticker: "USD", group: "Наличные деньги" },
]

export const exchangers: Exchanger[] = [
  { id: "e1", name: "БухтаОбмена", rating: 4.9, reviews: 9291, age: "6 лет", reserve: 5000000, minAmount: 100, maxAmount: 500000 },
  { id: "e2", name: "Char", rating: 4.7, reviews: 362, age: "3 года", reserve: 2736663674, minAmount: 50, maxAmount: 300000 },
  { id: "e3", name: "HASchange", rating: 4.8, reviews: 3674, age: "5 лет", reserve: 7263832, minAmount: 200, maxAmount: 1000000 },
  { id: "e4", name: "SafelyChange", rating: 4.8, reviews: 89849, age: "7 лет", reserve: 128759, minAmount: 100, maxAmount: 250000 },
  { id: "e5", name: "Cashalot", rating: 4.6, reviews: 983, age: "4 года", reserve: 729930, minAmount: 50, maxAmount: 750000 },
  { id: "e6", name: "MegaChange", rating: 4.5, reviews: 543, age: "3 года", reserve: 195608031, minAmount: 500, maxAmount: 200000 },
  { id: "e7", name: "Wirebit", rating: 4.7, reviews: 585, age: "5 лет", reserve: 8952000, minAmount: 100, maxAmount: 2000000 },
  { id: "e8", name: "MultiKassa", rating: 4.4, reviews: 682, age: "2 года", reserve: 2500000, minAmount: 100, maxAmount: 150000 },
  { id: "e9", name: "CoinDrop", rating: 4.6, reviews: 20043, age: "5 лет", reserve: 3500000, minAmount: 200, maxAmount: 500000 },
  { id: "e10", name: "Big-Changer", rating: 4.5, reviews: 1468, age: "3 года", reserve: 489418, minAmount: 100, maxAmount: 100000 },
  { id: "e11", name: "ProstoCash", rating: 4.9, reviews: 15234, age: "9 лет", reserve: 8500000, minAmount: 100, maxAmount: 1500000 },
  { id: "e12", name: "Baksman", rating: 4.8, reviews: 11200, age: "7 лет", reserve: 6700000, minAmount: 50, maxAmount: 400000 },
  { id: "e13", name: "FastChange", rating: 4.8, reviews: 9876, age: "8 лет", reserve: 4100000, minAmount: 100, maxAmount: 300000 },
  { id: "e14", name: "24PayBank", rating: 4.7, reviews: 8921, age: "8 лет", reserve: 3200000, minAmount: 200, maxAmount: 800000 },
  { id: "e15", name: "XChange", rating: 4.5, reviews: 3456, age: "4 года", reserve: 900000, minAmount: 100, maxAmount: 250000 },
  { id: "e16", name: "ExHub", rating: 4.9, reviews: 12453, age: "6 лет", reserve: 5000000, minAmount: 100, maxAmount: 500000 },
]

export const popularPairs = [
  { from: "btc", to: "sber" },
  { from: "usdt-trc20", to: "sber" },
  { from: "sber", to: "btc" },
  { from: "sber", to: "usdt-trc20" },
  { from: "eth", to: "sber" },
  { from: "tbank", to: "btc" },
  { from: "tbank", to: "usdt-trc20" },
  { from: "btc", to: "tbank" },
  { from: "usdt-trc20", to: "tbank" },
  { from: "ltc", to: "sber" },
  { from: "sber", to: "eth" },
  { from: "btc", to: "usdt-trc20" },
  { from: "usdt-trc20", to: "btc" },
  { from: "xrp", to: "sber" },
  { from: "sber", to: "ltc" },
  { from: "trx", to: "sber" },
  { from: "card-rub", to: "btc" },
  { from: "btc", to: "eth" },
  { from: "eth", to: "btc" },
  { from: "usdt-erc20", to: "sber" },
]

function seededRandom(seed: number): number {
  const x = Math.sin(seed) * 10000
  return x - Math.floor(x)
}

export function getCurrency(id: string): Currency | undefined {
  return currencies.find((c) => c.id === id)
}

export function getExchanger(id: string): Exchanger | undefined {
  return exchangers.find((e) => e.id === id)
}

export function generateRates(fromId: string, toId: string): ExchangeRate[] {
  const seed = (fromId + toId).split("").reduce((a, c) => a + c.charCodeAt(0), 0)
  const numExchangers = 6 + Math.floor(seededRandom(seed) * 10)
  const used = new Set<number>()
  const rates: ExchangeRate[] = []

  for (let i = 0; i < Math.min(numExchangers, exchangers.length); i++) {
    let idx = Math.floor(seededRandom(seed * (i + 1) + i * 7) * exchangers.length)
    let attempts = 0
    while (used.has(idx) && attempts < exchangers.length) {
      idx = (idx + 1) % exchangers.length
      attempts++
    }
    if (used.has(idx)) continue
    used.add(idx)

    const e = exchangers[idx]
    const variation = 0.97 + seededRandom(seed * (i + 3)) * 0.06

    let baseGive = 1
    let baseReceive = 1

    const isCrypto = (id: string) => ["btc", "bch", "eth", "ltc", "xrp", "xmr", "trx", "sol", "bnb-bep20", "doge", "ton", "ada", "zec"].includes(id)
    const isRub = (id: string) => ["sber", "tbank", "alfa", "vtb", "card-rub", "iomoney", "cash-rub", "zk-rub"].includes(id)
    const isStable = (id: string) => ["usdt-trc20", "usdt-erc20", "usdt-bep20", "usdt-ton", "usdc-erc20", "payeer", "volet", "wmz"].includes(id)

    if (isCrypto(fromId) && isRub(toId)) {
      const prices: Record<string, number> = { btc: 5316563, bch: 42000, eth: 320000, ltc: 12500, xrp: 85, xmr: 21000, trx: 17.5, sol: 26000, "bnb-bep20": 92000, doge: 28, ton: 4500, ada: 65, zec: 3200 }
      baseGive = 1
      baseReceive = (prices[fromId] || 50000) * variation
    } else if (isRub(fromId) && isCrypto(toId)) {
      const prices: Record<string, number> = { btc: 5339733, bch: 43000, eth: 325000, ltc: 12800, xrp: 87, xmr: 21500, trx: 18, sol: 26500, "bnb-bep20": 93000, doge: 29, ton: 4600, ada: 67, zec: 3300 }
      baseGive = (prices[toId] || 50000) * variation
      baseReceive = 1
    } else if (isStable(fromId) && isRub(toId)) {
      baseGive = 1
      baseReceive = 77.8 * variation
    } else if (isRub(fromId) && isStable(toId)) {
      baseGive = 79.31 * variation
      baseReceive = 1
    } else if (isCrypto(fromId) && isStable(toId)) {
      const prices: Record<string, number> = { btc: 97000, bch: 540, eth: 3550, ltc: 138, xrp: 0.94, xmr: 240, trx: 0.19, sol: 288, "bnb-bep20": 1020, doge: 0.31, ton: 52, ada: 0.75, zec: 37 }
      baseGive = 1
      baseReceive = (prices[fromId] || 100) * variation
    } else if (isStable(fromId) && isCrypto(toId)) {
      const prices: Record<string, number> = { btc: 97500, bch: 545, eth: 3580, ltc: 140, xrp: 0.96, xmr: 245, trx: 0.195, sol: 290, "bnb-bep20": 1030, doge: 0.315, ton: 53, ada: 0.77, zec: 38 }
      baseGive = (prices[toId] || 100) * variation
      baseReceive = 1
    } else if (isCrypto(fromId) && isCrypto(toId)) {
      const prices: Record<string, number> = { btc: 97000, bch: 540, eth: 3550, ltc: 138, xrp: 0.94, xmr: 240, trx: 0.19, sol: 288, "bnb-bep20": 1020, doge: 0.31, ton: 52, ada: 0.75, zec: 37 }
      baseGive = 1
      baseReceive = ((prices[fromId] || 100) / (prices[toId] || 100)) * variation
    } else {
      baseGive = 1
      baseReceive = variation
    }

    rates.push({
      exchangerId: e.id,
      give: Math.round(baseGive * 100000) / 100000,
      receive: Math.round(baseReceive * 100000) / 100000,
      reserve: Math.floor(e.reserve * (0.5 + seededRandom(seed * (i + 5)) * 0.5)),
      minAmount: e.minAmount,
      maxAmount: e.maxAmount,
    })
  }

  return rates.sort((a, b) => b.receive / b.give - a.receive / a.give)
}

export function formatNumber(n: number): string {
  if (n >= 1000000) return n.toLocaleString("ru-RU", { maximumFractionDigits: 0 })
  if (n >= 1000) return n.toLocaleString("ru-RU", { maximumFractionDigits: 0 })
  if (n < 0.001) return n.toFixed(6)
  if (n < 1) return n.toFixed(4)
  if (n < 100) return n.toFixed(2)
  return n.toLocaleString("ru-RU", { maximumFractionDigits: 2 })
}

export function getCurrencyGroups(): Record<string, Currency[]> {
  const g: Record<string, Currency[]> = {}
  currencies.forEach((c) => {
    if (!g[c.group]) g[c.group] = []
    g[c.group].push(c)
  })
  return g
}
